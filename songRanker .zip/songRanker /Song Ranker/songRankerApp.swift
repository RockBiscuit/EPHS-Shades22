//
//  songRankerApp.swift
//  songRanker
//
//  Created by 90308616 on 4/27/22.
//

import SwiftUI

@main
struct songRankerApp: App {
    var body: some Scene {
        WindowGroup {
            tabView()
        }
    }
}
