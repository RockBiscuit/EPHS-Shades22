//
//  rankedAlbums.swift
//  songRanker
//
//  Created by 90308616 on 5/17/22.
//

import SwiftUI

struct rankedAlbums: View {
    var body: some View {
        Text("You haven't ranked any albums yet!")
        
    }
}

struct rankedAlbums_Previews: PreviewProvider {
    static var previews: some View {
        rankedAlbums()
    }
}
